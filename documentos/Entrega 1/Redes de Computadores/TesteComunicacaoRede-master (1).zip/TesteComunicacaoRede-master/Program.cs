﻿using System;
using TesteComunicacaoRede;

class Program
{
    static void Main()
    {
        Console.WriteLine("Digite 1 para iniciar o Servidor, 2 para iniciar o Cliente:");
        string escolha = Console.ReadLine();

        if (escolha == "1")
            SmartHomeServer.Iniciar();
        else if (escolha == "2")
            SmartHomeCliente.Iniciar();
        else
            Console.WriteLine("Opção inválida.");
    }
}

