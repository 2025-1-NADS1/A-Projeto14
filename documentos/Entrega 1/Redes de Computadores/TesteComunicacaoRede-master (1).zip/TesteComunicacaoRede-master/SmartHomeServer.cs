﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace TesteComunicacaoRede
{
    internal class SmartHomeServer
    {
        public static void Iniciar()
        {
            TcpListener servidor = new TcpListener(IPAddress.Any, 5000);
            servidor.Start();
            Console.WriteLine("Servidor aguardando conexões...");

            while (true)
            {
                TcpClient cliente = servidor.AcceptTcpClient();
                NetworkStream stream = cliente.GetStream();

                byte[] buffer = new byte[1024];
                int bytesLidos = stream.Read(buffer, 0, buffer.Length);
                string mensagemRecebida = Encoding.UTF8.GetString(buffer, 0, bytesLidos);
                Console.WriteLine($"Recebido do cliente: {mensagemRecebida}");

                string resposta = "OK";
                byte[] dadosResposta = Encoding.UTF8.GetBytes(resposta);
                stream.Write(dadosResposta, 0, dadosResposta.Length);

                cliente.Close();
            }
        }
    }

}

