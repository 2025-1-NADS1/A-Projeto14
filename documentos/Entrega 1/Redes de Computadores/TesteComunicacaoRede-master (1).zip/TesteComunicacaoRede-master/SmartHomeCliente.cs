﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace TesteComunicacaoRede
{
    internal class SmartHomeCliente
    {
        public static void Iniciar()
        {
            try
            {
                TcpClient cliente = new TcpClient("127.0.0.1", 5000); // IP do servidor
                NetworkStream stream = cliente.GetStream();

                string mensagem = "Sensor: Temperatura = 25°C";
                byte[] dados = Encoding.UTF8.GetBytes(mensagem);
                stream.Write(dados, 0, dados.Length);
                Console.WriteLine("Mensagem enviada ao servidor.");

                byte[] buffer = new byte[1024];
                int bytesLidos = stream.Read(buffer, 0, buffer.Length);
                string resposta = Encoding.UTF8.GetString(buffer, 0, bytesLidos);
                Console.WriteLine($"Resposta do servidor: {resposta}");

                cliente.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro de conexão: " + ex.Message);
            }
        }
    }

}

